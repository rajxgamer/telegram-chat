const username = localStorage.getItem("username");
if (!username && location.pathname.includes("chat")) {
  location.href = "/";
}

document.getElementById("userLabel")?.innerText = "Logged in as: " + username;
const ws = new WebSocket(`wss://${location.host}`);
const chatBox = document.getElementById("chatBox");

ws.onmessage = (event) => {
  const msg = JSON.parse(event.data);
  const div = document.createElement("div");
  div.className = "message";
  div.innerText = `${msg.user}: ${msg.text}`;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
};

function send() {
  const input = document.getElementById("msgInput");
  if (input.value.trim()) {
    const msg = { user: username, text: input.value };
    ws.send(JSON.stringify(msg));
    input.value = "";
  }
}